from django.contrib import admin
from contact_us.models import ContactRequest


admin.site.register(ContactRequest)
