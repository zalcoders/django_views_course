from django.contrib import admin
from uploader.models import UploaddedFile


admin.site.register(UploaddedFile)
